package com.autosave.AutoSaveAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoSaveApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoSaveApiApplication.class, args);
	}

}
